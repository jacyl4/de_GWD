<?php
passthru('curl http://members.3322.org/dyndns/getip');
die();
?>
