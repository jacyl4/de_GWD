<?php
system('/usr/local/bin/ui-testbaidu');
?>