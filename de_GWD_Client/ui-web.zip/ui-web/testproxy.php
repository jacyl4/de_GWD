<?php
echo exec('/usr/local/bin/ui-testproxy');
?>