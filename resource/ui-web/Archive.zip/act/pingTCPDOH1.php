<?php
passthru('/opt/de_GWD/ui-pingTCPDOH1');
die();
?>
