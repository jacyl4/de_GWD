<?php
system('/usr/local/bin/ui-testgoogle');
?>