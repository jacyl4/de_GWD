<?php
echo shell_exec('/usr/local/bin/ui-testbaidu');
?>