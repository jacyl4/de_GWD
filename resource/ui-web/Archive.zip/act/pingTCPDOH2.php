<?php
passthru('/opt/de_GWD/ui-pingTCPDOH 2');
die();
?>
