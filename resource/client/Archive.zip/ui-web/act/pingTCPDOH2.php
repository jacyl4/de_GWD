<?php
passthru('/opt/de_GWD/ui-pingTCPDOH2');
die();
?>
