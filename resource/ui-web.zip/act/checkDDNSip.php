<?php
echo shell_exec("curl http://members.3322.org/dyndns/getip");
die();
?>
