<?php
passthru('/opt/de_GWD/ui-pingTCPDoG');
die();
?>
